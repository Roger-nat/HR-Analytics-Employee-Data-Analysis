"""
generate_dataset.py
--------------------
Generates a realistic, intentionally 'messy' raw HR dataset for the
HR Analytics & Employee Data Analysis project.

Why messy on purpose?
Real-world HR exports from tools like SAP/Workday almost always have:
  - missing values (blank fields, HR forgot to fill something)
  - duplicate rows (double export / double entry)
  - inconsistent text casing ("Male" vs "male" vs "MALE")
  - stray whitespace around strings
  - a few invalid / out-of-range numeric values (data entry errors)

This lets the cleaning script (src/data_cleaning.py) have real problems
to solve instead of working on already-perfect data.

Run:
    python src/generate_dataset.py
Produces:
    data/employees.csv
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta

# Reproducible randomness so the dataset is the same every time you run this
np.random.seed(42)

N_CLEAN_RECORDS = 850  # number of unique employees before we inject dirt

departments = {
    "Sales": ["Sales Executive", "Sales Manager", "Account Manager"],
    "Engineering": ["Software Engineer", "Senior Software Engineer", "QA Engineer", "DevOps Engineer"],
    "HR": ["HR Executive", "HR Manager", "Recruiter"],
    "Finance": ["Financial Analyst", "Accountant", "Finance Manager"],
    "Marketing": ["Marketing Executive", "SEO Specialist", "Marketing Manager"],
    "Operations": ["Operations Executive", "Operations Manager", "Logistics Coordinator"],
}

dept_list = list(departments.keys())

# Base salary ranges per department (in INR per month, to keep numbers realistic
# for a fresher-friendly Indian HR dataset; feel free to change currency mentally)
dept_salary_range = {
    "Sales": (25000, 90000),
    "Engineering": (35000, 160000),
    "HR": (22000, 80000),
    "Finance": (28000, 110000),
    "Marketing": (24000, 95000),
    "Operations": (20000, 75000),
}

rows = []
for emp_id in range(1001, 1001 + N_CLEAN_RECORDS):
    dept = np.random.choice(dept_list)
    role = np.random.choice(departments[dept])

    age = int(np.random.randint(21, 59))
    gender = np.random.choice(["Male", "Female"], p=[0.58, 0.42])

    experience_years = round(np.clip(np.random.exponential(scale=5), 0, 35), 1)

    low, high = dept_salary_range[dept]
    # more experience -> generally higher salary, plus noise
    exp_factor = min(experience_years / 15, 1.0)
    salary = int(low + (high - low) * exp_factor + np.random.normal(0, (high - low) * 0.08))
    salary = max(salary, low)

    # Joining date: somewhere in the last 12 years up to today
    days_ago = int(np.random.randint(30, 12 * 365))
    joining_date = datetime.today() - timedelta(days=days_ago)

    attendance_percentage = round(np.clip(np.random.normal(90, 7), 45, 100), 1)
    performance_score = int(np.clip(np.random.normal(3.2, 0.9), 1, 5))
    job_satisfaction = int(np.clip(np.random.normal(3.0, 1.0), 1, 5))

    # Attrition more likely with low satisfaction / low performance / low attendance
    attrition_prob = 0.06
    if job_satisfaction <= 2:
        attrition_prob += 0.25
    if performance_score <= 2:
        attrition_prob += 0.15
    if attendance_percentage < 75:
        attrition_prob += 0.15
    attrition = "Yes" if np.random.rand() < min(attrition_prob, 0.9) else "No"

    rows.append({
        "employee_id": emp_id,
        "age": age,
        "gender": gender,
        "department": dept,
        "job_role": role,
        "experience_years": experience_years,
        "salary": salary,
        "joining_date": joining_date.strftime("%Y-%m-%d"),
        "attendance_percentage": attendance_percentage,
        "performance_score": performance_score,
        "job_satisfaction": job_satisfaction,
        "attrition": attrition,
    })

df = pd.DataFrame(rows)

# ---------------------------------------------------------------------------
# INJECT REALISTIC DIRT
# ---------------------------------------------------------------------------

# 1) Inconsistent text casing / stray whitespace (simulates manual data entry)
messy_idx = np.random.choice(df.index, size=60, replace=False)
for i in messy_idx:
    choice = np.random.choice(["upper", "lower", "space"])
    if choice == "upper":
        df.loc[i, "gender"] = df.loc[i, "gender"].upper()
    elif choice == "lower":
        df.loc[i, "department"] = df.loc[i, "department"].lower()
    else:
        df.loc[i, "job_role"] = f"  {df.loc[i, 'job_role']}  "

# 2) Missing values scattered across several columns (simulate incomplete HR forms)
for col, frac in [
    ("age", 0.02),
    ("gender", 0.015),
    ("salary", 0.03),
    ("attendance_percentage", 0.04),
    ("performance_score", 0.03),
    ("job_satisfaction", 0.03),
    ("experience_years", 0.02),
    ("department", 0.01),
]:
    n_missing = int(len(df) * frac)
    idx = np.random.choice(df.index, size=n_missing, replace=False)
    df.loc[idx, col] = np.nan

# 3) A few invalid / out-of-range numeric values (data entry errors)
invalid_idx = np.random.choice(df.index, size=8, replace=False)
for i in invalid_idx:
    field = np.random.choice(["age", "salary", "attendance_percentage"])
    if field == "age":
        df.loc[i, "age"] = np.random.choice([-5, 0, 150])
    elif field == "salary":
        df.loc[i, "salary"] = np.random.choice([-1000, 0])
    else:
        df.loc[i, "attendance_percentage"] = np.random.choice([-10, 130])

# 4) Duplicate rows (simulate double export / accidental re-upload)
dup_rows = df.sample(n=45, random_state=7)
df = pd.concat([df, dup_rows], ignore_index=True)

# 5) Shuffle so duplicates aren't neatly at the bottom (more realistic)
df = df.sample(frac=1, random_state=1).reset_index(drop=True)

df.to_csv("data/employees.csv", index=False)

print(f"Generated data/employees.csv with {len(df)} rows (includes duplicates & missing values).")
print(df.isna().sum())
