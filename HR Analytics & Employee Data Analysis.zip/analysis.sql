-- =============================================================
-- HR Analytics & Employee Data Analysis
-- analysis.sql : SQL analytics queries
-- =============================================================
-- Run with:
--   mysql -u root -p hr_analytics < sql/analysis.sql
-- or paste individual queries into a MySQL client / Workbench.
-- =============================================================

USE hr_analytics;

-- 1. Total employees
SELECT COUNT(*) AS total_employees
FROM employees;

-- 2. Employees by department
SELECT department, COUNT(*) AS employee_count
FROM employees
GROUP BY department
ORDER BY employee_count DESC;

-- 3. Average salary by department
SELECT department, ROUND(AVG(salary), 2) AS avg_salary
FROM employees
GROUP BY department
ORDER BY avg_salary DESC;

-- 4. Highest-paid employees (Top 10)
SELECT employee_id, department, job_role, salary
FROM employees
ORDER BY salary DESC
LIMIT 10;

-- 5. Average experience by department
SELECT department, ROUND(AVG(experience_years), 2) AS avg_experience_years
FROM employees
GROUP BY department
ORDER BY avg_experience_years DESC;

-- 6. Employees with highest performance scores (top performers, score = 5)
SELECT employee_id, department, job_role, performance_score
FROM employees
WHERE performance_score = (SELECT MAX(performance_score) FROM employees)
ORDER BY employee_id;

-- 7. Overall attrition rate (%)
SELECT
    ROUND(SUM(attrition_flag) * 100.0 / COUNT(*), 2) AS attrition_rate_pct
FROM employees;

-- 8. Attrition by department
SELECT
    department,
    COUNT(*)                                   AS total_employees,
    SUM(attrition_flag)                        AS employees_left,
    ROUND(SUM(attrition_flag) * 100.0 / COUNT(*), 2) AS attrition_rate_pct
FROM employees
GROUP BY department
ORDER BY attrition_rate_pct DESC;

-- 9. Average salary by job role
SELECT job_role, ROUND(AVG(salary), 2) AS avg_salary
FROM employees
GROUP BY job_role
ORDER BY avg_salary DESC;

-- 10. Employees with more than 5 years of experience
SELECT employee_id, department, job_role, experience_years
FROM employees
WHERE experience_years > 5
ORDER BY experience_years DESC;

-- 11. Average attendance by department
SELECT department, ROUND(AVG(attendance_percentage), 2) AS avg_attendance_pct
FROM employees
GROUP BY department
ORDER BY avg_attendance_pct DESC;

-- 12. Employee distribution by job role
SELECT
    job_role,
    COUNT(*) AS employee_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM employees), 2) AS pct_of_workforce
FROM employees
GROUP BY job_role
ORDER BY employee_count DESC;
