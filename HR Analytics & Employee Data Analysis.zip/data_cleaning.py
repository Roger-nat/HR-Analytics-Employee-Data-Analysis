"""
data_cleaning.py
-----------------
HR Analytics & Employee Data Analysis
Step 2 of the pipeline: Python / Pandas cleaning & transformation.

Raw CSV (data/employees.csv)
        |
        v
This script
        |
        v
Cleaned CSV (output/cleaned_employees.csv)  -> loaded into MySQL next

Each step below is numbered to match the project requirements so it's
easy to explain in an interview:
    1. Load the CSV
    2. Inspect the dataset
    3. Identify missing values
    4. Remove duplicate records
    5. Handle missing values
    6. Standardize column formats
    7. Validate numerical values
    8. Convert joining_date to datetime
    9. Create derived fields
    10. Export the cleaned dataset
"""

import pandas as pd
import numpy as np

RAW_PATH = "data/employees.csv"
CLEAN_PATH = "output/cleaned_employees.csv"


def load_data(path: str) -> pd.DataFrame:
    """Step 1: Load the raw CSV into a DataFrame."""
    df = pd.read_csv(path)
    print(f"[1] Loaded {len(df)} rows, {df.shape[1]} columns from {path}")
    return df


def inspect_data(df: pd.DataFrame) -> None:
    """Step 2: Basic inspection — shape, dtypes, head, summary stats."""
    print("\n[2] --- Dataset Inspection ---")
    print("Shape:", df.shape)
    print("\nDtypes:\n", df.dtypes)
    print("\nFirst 5 rows:\n", df.head())
    print("\nNumeric summary:\n", df.describe(include="number"))


def identify_missing(df: pd.DataFrame) -> None:
    """Step 3: Report missing values per column."""
    print("\n[3] --- Missing Values ---")
    missing = df.isna().sum()
    missing_pct = (missing / len(df) * 100).round(2)
    report = pd.DataFrame({"missing_count": missing, "missing_pct": missing_pct})
    print(report[report["missing_count"] > 0])


def remove_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    """Step 4: Drop exact duplicate rows.

    We use employee_id + all other columns being identical as "exact duplicate".
    If only employee_id repeats (same employee appearing twice with different
    other values), we keep the first occurrence, since that indicates a
    duplicate submission rather than two different employees.
    """
    before = len(df)
    df = df.drop_duplicates()
    after_exact = len(df)
    df = df.drop_duplicates(subset="employee_id", keep="first")
    after_id = len(df)
    print(f"\n[4] Removed {before - after_exact} exact duplicate rows, "
          f"{after_exact - after_id} duplicate employee_id rows. "
          f"Rows remaining: {after_id}")
    return df


def handle_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """Step 5: Fill/handle missing values with sensible, explainable rules.

    Strategy (typical for a fresher-level project — simple & explainable
    beats "fancy" imputation):
      - Numeric columns  -> median (robust to outliers, unlike mean)
      - Categorical (gender, department) -> mode (most frequent value)
    """
    numeric_cols = ["age", "experience_years", "salary",
                     "attendance_percentage", "performance_score",
                     "job_satisfaction"]
    categorical_cols = ["gender", "department"]

    for col in numeric_cols:
        median_val = df[col].median()
        n_missing = df[col].isna().sum()
        df[col] = df[col].fillna(median_val)
        if n_missing:
            print(f"[5] Filled {n_missing} missing '{col}' values with median = {median_val}")

    for col in categorical_cols:
        mode_val = df[col].mode(dropna=True)[0]
        n_missing = df[col].isna().sum()
        df[col] = df[col].fillna(mode_val)
        if n_missing:
            print(f"[5] Filled {n_missing} missing '{col}' values with mode = '{mode_val}'")

    return df


def standardize_formats(df: pd.DataFrame) -> pd.DataFrame:
    """Step 6: Standardize text formatting (casing, whitespace)."""
    df["gender"] = df["gender"].str.strip().str.title()
    df["department"] = df["department"].str.strip().str.title()
    df["job_role"] = df["job_role"].str.strip().str.title()
    df["attrition"] = df["attrition"].str.strip().str.title()

    # Collapse any accidental typo variants of gender into a known set
    df["gender"] = df["gender"].replace({"M": "Male", "F": "Female"})

    print("\n[6] Standardized text casing/whitespace for gender, department, "
          "job_role, attrition")
    return df


def validate_numeric_values(df: pd.DataFrame) -> pd.DataFrame:
    """Step 7: Validate numeric ranges and fix/flag invalid data.

    Business rules used here (typical HR bounds):
      - age: must be between 18 and 65 -> otherwise replaced with median age
      - salary: must be > 0 -> otherwise replaced with department median salary
      - attendance_percentage: must be between 0 and 100 -> clipped
      - performance_score / job_satisfaction: must be between 1 and 5 -> clipped
    """
    median_age = df.loc[df["age"].between(18, 65), "age"].median()
    invalid_age = ~df["age"].between(18, 65)
    print(f"\n[7] Found {invalid_age.sum()} invalid 'age' values -> replaced with median ({median_age})")
    df.loc[invalid_age, "age"] = median_age
    df["age"] = df["age"].astype(int)

    invalid_salary = df["salary"] <= 0
    dept_median_salary = df.groupby("department")["salary"].transform("median")
    print(f"[7] Found {invalid_salary.sum()} invalid 'salary' values -> replaced with department median")
    df.loc[invalid_salary, "salary"] = dept_median_salary[invalid_salary]
    df["salary"] = df["salary"].astype(int)

    out_of_range_att = ~df["attendance_percentage"].between(0, 100)
    print(f"[7] Found {out_of_range_att.sum()} out-of-range 'attendance_percentage' values -> clipped to [0, 100]")
    df["attendance_percentage"] = df["attendance_percentage"].clip(0, 100)

    df["performance_score"] = df["performance_score"].clip(1, 5).round().astype(int)
    df["job_satisfaction"] = df["job_satisfaction"].clip(1, 5).round().astype(int)

    df["experience_years"] = df["experience_years"].clip(lower=0)

    return df


def convert_dates(df: pd.DataFrame) -> pd.DataFrame:
    """Step 8: Convert joining_date to a proper datetime dtype."""
    df["joining_date"] = pd.to_datetime(df["joining_date"], errors="coerce")
    n_bad_dates = df["joining_date"].isna().sum()
    if n_bad_dates:
        # If any dates failed to parse, fall back to the overall median date
        median_date = df["joining_date"].median()
        df["joining_date"] = df["joining_date"].fillna(median_date)
        print(f"\n[8] Converted joining_date to datetime "
              f"({n_bad_dates} unparseable values filled with median date)")
    else:
        print("\n[8] Converted joining_date to datetime (no parsing errors)")
    return df


def create_derived_fields(df: pd.DataFrame) -> pd.DataFrame:
    """Step 9: Feature engineering — useful derived columns for analysis.

      - tenure_years: how long the employee has been with the company
      - age_group: bucketed age for easy group-by analysis
      - salary_band: bucketed salary for easy group-by analysis
      - is_high_performer: performance_score >= 4
      - attrition_flag: 1/0 numeric version of attrition (handy for SQL/BI)
    """
    today = pd.Timestamp.today()
    df["tenure_years"] = ((today - df["joining_date"]).dt.days / 365.25).round(1)

    df["age_group"] = pd.cut(
        df["age"],
        bins=[17, 25, 35, 45, 55, 65],
        labels=["18-25", "26-35", "36-45", "46-55", "56-65"],
    )

    df["salary_band"] = pd.cut(
        df["salary"],
        bins=[0, 30000, 60000, 100000, np.inf],
        labels=["Low", "Medium", "High", "Very High"],
    )

    df["is_high_performer"] = (df["performance_score"] >= 4).astype(int)
    df["attrition_flag"] = (df["attrition"] == "Yes").astype(int)

    print("\n[9] Created derived fields: tenure_years, age_group, salary_band, "
          "is_high_performer, attrition_flag")
    return df


def export_data(df: pd.DataFrame, path: str) -> None:
    """Step 10: Export the cleaned dataset to CSV."""
    df.to_csv(path, index=False)
    print(f"\n[10] Exported cleaned dataset -> {path} ({len(df)} rows, {df.shape[1]} columns)")


def main():
    df = load_data(RAW_PATH)
    inspect_data(df)
    identify_missing(df)
    df = remove_duplicates(df)
    df = handle_missing_values(df)
    df = standardize_formats(df)
    df = validate_numeric_values(df)
    df = convert_dates(df)
    df = create_derived_fields(df)

    # Reorder columns for readability
    column_order = [
        "employee_id", "age", "age_group", "gender", "department", "job_role",
        "experience_years", "tenure_years", "salary", "salary_band",
        "joining_date", "attendance_percentage", "performance_score",
        "is_high_performer", "job_satisfaction", "attrition", "attrition_flag",
    ]
    df = df[column_order]

    export_data(df, CLEAN_PATH)

    print("\n--- Final Data Quality Check ---")
    print("Remaining missing values:\n", df.isna().sum().sum())
    print("Remaining duplicate employee_ids:", df["employee_id"].duplicated().sum())


if __name__ == "__main__":
    main()
