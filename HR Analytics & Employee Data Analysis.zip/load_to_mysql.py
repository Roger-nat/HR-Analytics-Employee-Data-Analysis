"""
load_to_mysql.py
------------------
Step 3 of the pipeline: load the cleaned CSV into MySQL.

Prerequisites:
    1. MySQL server running locally (or remotely).
    2. You've already run: mysql -u root -p < sql/schema.sql
       (this creates the `hr_analytics` database and `employees` table)
    3. pip install -r requirements.txt

Usage:
    python src/load_to_mysql.py --host localhost --user root --password YOURPASSWORD

You can also just edit the DB_CONFIG dict below and run:
    python src/load_to_mysql.py
"""

import argparse
import pandas as pd
from sqlalchemy import create_engine

CLEAN_PATH = "output/cleaned_employees.csv"

DB_CONFIG = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "your_password_here",
    "database": "hr_analytics",
}


def get_engine(cfg):
    url = (
        f"mysql+pymysql://{cfg['user']}:{cfg['password']}"
        f"@{cfg['host']}:{cfg['port']}/{cfg['database']}"
    )
    return create_engine(url)


def main():
    parser = argparse.ArgumentParser(description="Load cleaned_employees.csv into MySQL")
    parser.add_argument("--host", default=DB_CONFIG["host"])
    parser.add_argument("--port", type=int, default=DB_CONFIG["port"])
    parser.add_argument("--user", default=DB_CONFIG["user"])
    parser.add_argument("--password", default=DB_CONFIG["password"])
    parser.add_argument("--database", default=DB_CONFIG["database"])
    args = parser.parse_args()

    cfg = {
        "host": args.host,
        "port": args.port,
        "user": args.user,
        "password": args.password,
        "database": args.database,
    }

    print(f"Reading {CLEAN_PATH} ...")
    df = pd.read_csv(CLEAN_PATH, parse_dates=["joining_date"])

    # Booleans -> plain ints for MySQL TINYINT columns
    df["is_high_performer"] = df["is_high_performer"].astype(int)
    df["attrition_flag"] = df["attrition_flag"].astype(int)

    print(f"Connecting to MySQL database '{cfg['database']}' on {cfg['host']}:{cfg['port']} ...")
    engine = get_engine(cfg)

    print("Loading data into `employees` table (append mode; table already created by schema.sql) ...")
    df.to_sql(
        "employees",
        con=engine,
        if_exists="append",
        index=False,
        chunksize=200,
    )

    print(f"Done. Loaded {len(df)} rows into hr_analytics.employees")


if __name__ == "__main__":
    main()
