-- =============================================================
-- HR Analytics & Employee Data Analysis
-- schema.sql : creates the database and the employees table
-- =============================================================
-- Run with:
--   mysql -u root -p < sql/schema.sql
-- =============================================================

CREATE DATABASE IF NOT EXISTS hr_analytics
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE hr_analytics;

DROP TABLE IF EXISTS employees;

CREATE TABLE employees (
    employee_id            INT PRIMARY KEY,
    age                     TINYINT UNSIGNED NOT NULL CHECK (age BETWEEN 18 AND 65),
    age_group               VARCHAR(10),
    gender                  ENUM('Male', 'Female') NOT NULL,
    department              VARCHAR(50) NOT NULL,
    job_role                VARCHAR(50) NOT NULL,
    experience_years        DECIMAL(4,1) NOT NULL CHECK (experience_years >= 0),
    tenure_years            DECIMAL(4,1) NOT NULL CHECK (tenure_years >= 0),
    salary                  INT NOT NULL CHECK (salary > 0),
    salary_band             VARCHAR(20),
    joining_date            DATE NOT NULL,
    attendance_percentage   DECIMAL(5,2) NOT NULL CHECK (attendance_percentage BETWEEN 0 AND 100),
    performance_score       TINYINT UNSIGNED NOT NULL CHECK (performance_score BETWEEN 1 AND 5),
    is_high_performer       TINYINT(1) NOT NULL DEFAULT 0,
    job_satisfaction        TINYINT UNSIGNED NOT NULL CHECK (job_satisfaction BETWEEN 1 AND 5),
    attrition               ENUM('Yes', 'No') NOT NULL,
    attrition_flag          TINYINT(1) NOT NULL DEFAULT 0,

    INDEX idx_department (department),
    INDEX idx_job_role (job_role),
    INDEX idx_attrition (attrition)
) ENGINE=InnoDB;

-- Quick sanity check after loading data (run manually if you like):
-- SELECT COUNT(*) FROM employees;
-- SELECT * FROM employees LIMIT 10;
