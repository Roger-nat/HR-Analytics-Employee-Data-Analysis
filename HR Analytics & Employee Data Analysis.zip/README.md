# HR Analytics & Employee Data Analysis

A beginner-friendly, end-to-end Data Engineering portfolio project built for
fresher Data Engineer interviews. It takes a messy, realistic raw HR CSV
through cleaning, transformation, loading into MySQL, and SQL analytics —
the same shape as a real ETL/ELT pipeline, just at fresher scale.

```
Raw Employee CSV
       │
       ▼
Python / Pandas
       │
       ▼
Data Cleaning
       │
       ▼
Data Transformation
       │
       ▼
MySQL
       │
       ▼
SQL Analytics
```

## Project Structure

```
hr-analytics/
│
├── data/
│   └── employees.csv          # raw, intentionally messy dataset (~850-900 rows)
│
├── src/
│   ├── generate_dataset.py    # generates the raw synthetic dataset
│   ├── data_cleaning.py       # Pandas cleaning + transformation pipeline
│   └── load_to_mysql.py       # loads cleaned data into MySQL
│
├── sql/
│   ├── schema.sql             # CREATE DATABASE + CREATE TABLE (PK, constraints)
│   └── analysis.sql           # 12 SQL analytics queries
│
├── output/
│   └── cleaned_employees.csv  # cleaned, analysis-ready dataset
│
├── requirements.txt
└── README.md
```

## Dataset

Synthetic but realistic employee records with these columns:

| Column | Description |
|---|---|
| employee_id | Unique employee identifier |
| age | Employee age |
| gender | Male / Female |
| department | Sales, Engineering, HR, Finance, Marketing, Operations |
| job_role | Role within the department |
| experience_years | Total years of professional experience |
| salary | Monthly salary |
| joining_date | Date the employee joined the company |
| attendance_percentage | % attendance |
| performance_score | 1 (low) – 5 (high) |
| job_satisfaction | 1 (low) – 5 (high) |
| attrition | Yes / No — whether the employee has left |

The raw file intentionally contains **missing values, duplicate rows,
inconsistent text casing/whitespace, and a few invalid numeric values**
(negative ages, 0 salaries, out-of-range attendance) so the cleaning
step has real problems to solve — just like a real HR data export would.

## Setup Instructions

### 1. Clone / download the project and set up Python

```bash
cd hr-analytics
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Generate the raw dataset

```bash
python src/generate_dataset.py
```

This creates `data/employees.csv` (~850-900 rows, with dirt injected).

### 3. Run the cleaning & transformation pipeline

```bash
python src/data_cleaning.py
```

This reads `data/employees.csv`, cleans/transforms it, and writes
`output/cleaned_employees.csv`. The console output logs exactly what was
done at each step (rows removed, values filled, etc.) — useful to show an
interviewer.

### 4. Set up MySQL

Make sure a local MySQL server is running, then create the database and
table:

```bash
mysql -u root -p < sql/schema.sql
```

### 5. Load the cleaned data into MySQL

```bash
python src/load_to_mysql.py --host localhost --user root --password YOUR_PASSWORD
```

(Or edit the `DB_CONFIG` dictionary directly inside `src/load_to_mysql.py`
instead of passing flags.)

### 6. Run the SQL analysis queries

```bash
mysql -u root -p hr_analytics < sql/analysis.sql
```

Or open `sql/analysis.sql` in MySQL Workbench / DBeaver and run each query
individually to inspect the results one at a time.

## Explanation of Each Pipeline Step

**1. Load the CSV** — `pd.read_csv()` reads the raw file into a DataFrame.

**2. Inspect the dataset** — `.shape`, `.dtypes`, `.head()`, `.describe()`
give a first look at structure, data types, and numeric ranges.

**3. Identify missing values** — `.isna().sum()` counts nulls per column so
we know exactly what needs to be handled before doing any analysis.

**4. Remove duplicate records** — `.drop_duplicates()` removes exact
duplicate rows first, then removes any repeated `employee_id`s (keeping the
first occurrence), since the same employee should only appear once.

**5. Handle missing values** — Numeric columns (age, salary, experience,
attendance, performance, satisfaction) are filled with the **median**
(robust to outliers). Categorical columns (gender, department) are filled
with the **mode** (most frequent value). Both are simple, explainable
strategies appropriate for a fresher-level project.

**6. Standardize column formats** — Text columns are stripped of stray
whitespace and converted to consistent Title Case (`"MALE "` → `"Male"`,
`"engineering"` → `"Engineering"`) so grouping/filtering works correctly.

**7. Validate numerical values** — Business rules catch invalid entries:
age must be 18–65, salary must be positive, attendance must be 0–100,
performance/satisfaction scores must be 1–5. Invalid values are replaced
with a sensible statistic (median / department median) rather than just
dropped, to preserve as much data as possible.

**8. Convert joining_date to datetime** — `pd.to_datetime()` converts the
text date column into a real `datetime64` type so date arithmetic (like
tenure) becomes possible.

**9. Create derived fields** — New columns add analytical value:
- `tenure_years` — years since joining, computed from `joining_date`
- `age_group` — bucketed age (18-25, 26-35, …) for easy grouping
- `salary_band` — bucketed salary (Low/Medium/High/Very High)
- `is_high_performer` — 1 if performance_score ≥ 4, else 0
- `attrition_flag` — numeric (1/0) version of the `attrition` column, handy
  for SQL aggregation and future BI tools

**10. Export the cleaned dataset** — `.to_csv()` writes the final,
analysis-ready dataset to `output/cleaned_employees.csv`, which is then
loaded into MySQL.

## MySQL Schema Design Notes

- `employee_id` is the **PRIMARY KEY** (uniquely identifies each row).
- `CHECK` constraints enforce the same business rules used during Python
  validation (age 18–65, salary > 0, attendance 0–100, scores 1–5) — this
  is defense-in-depth: even if bad data got past Pandas, MySQL rejects it.
- `ENUM` is used for `gender` and `attrition` since they have a small,
  fixed set of valid values.
- Indexes on `department`, `job_role`, and `attrition` speed up the
  `GROUP BY` / `WHERE` queries used in `analysis.sql`.

## SQL Analytics Included

1. Total employees
2. Employees by department
3. Average salary by department
4. Highest-paid employees
5. Average experience by department
6. Employees with highest performance scores
7. Attrition rate
8. Attrition by department
9. Average salary by job role
10. Employees with more than 5 years experience
11. Average attendance by department
12. Employee distribution by job role

## Tech Stack

- **Python 3** + **Pandas** / **NumPy** — data cleaning & transformation
- **MySQL** — relational storage
- **SQLAlchemy** + **PyMySQL** — Python-to-MySQL connectivity
- **SQL** — analytics queries

Deliberately excluded (out of scope for a fresher project): machine
learning, Spark, Kafka, Airflow, cloud services. The goal is to
demonstrate solid fundamentals cleanly, not to over-engineer.
